CREATE TABLE SCOTT.DEPT 
(
	DEPT_ID     NUMBER (4) NOT NULL,
	DEPT_NAME   VARCHAR2 (30) CONSTRAINT DEPT_NAME_NN NOT NULL
);
ALTER TABLE SCOTT.DEPT ADD(PRIMARY KEY (DEPT_ID));

insert into SCOTT.DEPT values (10,'�����а�');
insert into SCOTT.DEPT values (20,'��ǻ�Ͱ��а�');
insert into SCOTT.DEPT values (30,'������а�');
insert into SCOTT.DEPT values (40,'������а�');
commit;

CREATE TABLE SCOTT.STUDENT 
(
	STU_ID         NUMBER (6) NOT NULL,
	STU_NAME       VARCHAR2 (20) NOT NULL,
	STU_AGE        NUMBER (3) NOT NULL,
	STU_GRADE      VARCHAR2 (20),
	STU_DAYNIGHT   VARCHAR2 (20),
	DEPT_ID        NUMBER (4) NOT NULL,
	CONSTRAINT FK_DEPT_IDS FOREIGN KEY (DEPT_ID) REFERENCES SCOTT.DEPT (DEPT_ID)
);
ALTER TABLE SCOTT.STUDENT ADD(PRIMARY KEY (STU_ID));

insert into scott.student values (1002,'ȫ�浿',20,'1�г�','�ְ�',30);
commit;
